<?php
    include("include/dbcommon.php");
echo "Hola";

?>